module.exports=[56180,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_thank-you_page_actions_1uoaixw.js.map