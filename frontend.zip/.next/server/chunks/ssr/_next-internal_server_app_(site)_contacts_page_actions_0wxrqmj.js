module.exports=[30923,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_contacts_page_actions_0wxrqmj.js.map