module.exports=[29867,a=>{"use strict";var b=a.i(87924),c=a.i(72131);a.s(["default",0,function({subtitle:a,eyebrow:d,title:e,titleHtml:f,description:g,dark:h,className:i=""}){let j=(0,c.useRef)(null);return(0,c.useEffect)(()=>{if(!j.current)return;let a=j.current,b=()=>{let b=a.closest("section")?.getBoundingClientRect()??a.parentElement?.getBoundingClientRect();if(!b)return;let c=(1-b.bottom/(b.height+window.innerHeight))*b.height*.4;a.style.transform=`translateY(${c}px)`};return window.addEventListener("scroll",b,{passive:!0}),b(),()=>window.removeEventListener("scroll",b)},[]),(0,b.jsxs)(b.Fragment,{children:[a&&(0,b.jsx)("div",{ref:j,className:"absolute top-[50px] left-[40px] right-0 font-black uppercase opacity-[0.15] text-[9.5vw] leading-none text-[#ccc] pointer-events-none text-left will-change-transform",children:a}),(d||e||f||g)&&(0,b.jsxs)("div",{className:`relative pl-[50px] py-5 mb-[50px] text-left
            before:content-[''] before:absolute before:top-0 before:left-[-2px]
            before:w-1 before:h-full before:bg-brand-yellow
            ${i}`,children:[d&&(0,b.jsx)("h3",{className:`relative pb-[30px] text-left font-semibold text-sm
                after:content-[''] after:absolute after:bottom-3 after:left-0
                after:w-[50px] after:border-b after:border-dotted after:border-[#666]
                ${h?"text-white/70":"text-brand-purple"}`,children:d}),f?(0,b.jsx)("h2",{className:`text-[40px] font-extrabold uppercase [&_span]:text-brand-yellow
                ${h?"text-white pb-[50px]":"text-[rgb(50,58,69)] pb-[30px]"}`,dangerouslySetInnerHTML:{__html:f}}):e?(0,b.jsx)("h2",{className:`text-[40px] font-extrabold uppercase
                ${h?"text-white pb-[50px]":"text-[rgb(50,58,69)] pb-[30px]"}`,children:e}):null,g&&(0,b.jsx)("p",{className:`text-left ${h?"text-white/70":""}`,children:g})]})]})}])}];

//# sourceMappingURL=src_components_ui_SectionTitle_tsx_0_wyzvq._.js.map