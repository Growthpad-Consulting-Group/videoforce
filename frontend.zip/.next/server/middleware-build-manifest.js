globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/oRzRw4S7l0vEOvuINOXJ0/_buildManifest.js",
    "static/oRzRw4S7l0vEOvuINOXJ0/_ssgManifest.js",
    "static/oRzRw4S7l0vEOvuINOXJ0/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2iho8jepmwwua.js",
    "static/chunks/0titdguvb_047.js",
    "static/chunks/0mk1g55o6kl1e.js",
    "static/chunks/1nx4qpfk-i_e-.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-2at1i210675jf.js"
  ]
};
